const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

exports.sendEmail = async ({ to, subject, html }) => {
  const mailOptions = {
    from: `"CertAuth" <${process.env.EMAIL_USER}>`,
    to,
    subject,
    html
  };
  return await transporter.sendMail(mailOptions);
};
